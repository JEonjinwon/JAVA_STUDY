package APT7;

public class ParkingVO {

	private int parking_loc;
	private int parking_addr;
	private int car_num;
	public int getParking_loc() {
		return parking_loc;
	}
	public void setParking_loc(int parking_loc) {
		this.parking_loc = parking_loc;
	}
	public int getParking_addr() {
		return parking_addr;
	}
	public void setParking_addr(int parking_addr) {
		this.parking_addr = parking_addr;
	}
	public int getCar_num() {
		return car_num;
	}
	public void setCar_num(int car_num) {
		this.car_num = car_num;
	}
	
	
}
